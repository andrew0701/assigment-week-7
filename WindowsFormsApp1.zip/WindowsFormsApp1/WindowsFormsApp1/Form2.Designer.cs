﻿namespace WindowsFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_TeamName = new System.Windows.Forms.Label();
            this.tb_TeamAdd = new System.Windows.Forms.TextBox();
            this.bt_AddForm2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_TeamName
            // 
            this.lb_TeamName.AutoSize = true;
            this.lb_TeamName.Location = new System.Drawing.Point(476, 125);
            this.lb_TeamName.Name = "lb_TeamName";
            this.lb_TeamName.Size = new System.Drawing.Size(140, 25);
            this.lb_TeamName.TabIndex = 0;
            this.lb_TeamName.Text = "Team Name :";
            // 
            // tb_TeamAdd
            // 
            this.tb_TeamAdd.Location = new System.Drawing.Point(401, 172);
            this.tb_TeamAdd.Name = "tb_TeamAdd";
            this.tb_TeamAdd.Size = new System.Drawing.Size(254, 31);
            this.tb_TeamAdd.TabIndex = 1;
            // 
            // bt_AddForm2
            // 
            this.bt_AddForm2.Location = new System.Drawing.Point(467, 232);
            this.bt_AddForm2.Name = "bt_AddForm2";
            this.bt_AddForm2.Size = new System.Drawing.Size(119, 44);
            this.bt_AddForm2.TabIndex = 2;
            this.bt_AddForm2.Text = "Add";
            this.bt_AddForm2.UseVisualStyleBackColor = true;
            this.bt_AddForm2.Click += new System.EventHandler(this.bt_AddForm2_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1088, 560);
            this.Controls.Add(this.bt_AddForm2);
            this.Controls.Add(this.tb_TeamAdd);
            this.Controls.Add(this.lb_TeamName);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_TeamName;
        private System.Windows.Forms.TextBox tb_TeamAdd;
        private System.Windows.Forms.Button bt_AddForm2;
    }
}
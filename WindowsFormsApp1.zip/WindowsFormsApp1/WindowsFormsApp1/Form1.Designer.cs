﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bt_Delete = new System.Windows.Forms.Button();
            this.comboBox_Kiri = new System.Windows.Forms.ComboBox();
            this.comboBox_Kanan = new System.Windows.Forms.ComboBox();
            this.lb_Vs = new System.Windows.Forms.Label();
            this.tb_ScoreKiri = new System.Windows.Forms.TextBox();
            this.tb_ScoreKanan = new System.Windows.Forms.TextBox();
            this.bt_AddMatch = new System.Windows.Forms.Button();
            this.bt_AddTeam = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(990, 719);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(575, 31);
            this.dateTimePicker1.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(2497, 677);
            this.dataGridView1.TabIndex = 1;
            // 
            // bt_Delete
            // 
            this.bt_Delete.Location = new System.Drawing.Point(26, 719);
            this.bt_Delete.Name = "bt_Delete";
            this.bt_Delete.Size = new System.Drawing.Size(139, 55);
            this.bt_Delete.TabIndex = 2;
            this.bt_Delete.Text = "Delete";
            this.bt_Delete.UseVisualStyleBackColor = true;
            this.bt_Delete.Click += new System.EventHandler(this.bt_Delete_Click);
            // 
            // comboBox_Kiri
            // 
            this.comboBox_Kiri.FormattingEnabled = true;
            this.comboBox_Kiri.Location = new System.Drawing.Point(990, 773);
            this.comboBox_Kiri.Name = "comboBox_Kiri";
            this.comboBox_Kiri.Size = new System.Drawing.Size(210, 33);
            this.comboBox_Kiri.TabIndex = 3;
            this.comboBox_Kiri.SelectedIndexChanged += new System.EventHandler(this.comboBox_Kiri_SelectedIndexChanged);
            // 
            // comboBox_Kanan
            // 
            this.comboBox_Kanan.FormattingEnabled = true;
            this.comboBox_Kanan.Location = new System.Drawing.Point(1353, 773);
            this.comboBox_Kanan.Name = "comboBox_Kanan";
            this.comboBox_Kanan.Size = new System.Drawing.Size(212, 33);
            this.comboBox_Kanan.TabIndex = 4;
            this.comboBox_Kanan.SelectedIndexChanged += new System.EventHandler(this.comboBox_Kanan_SelectedIndexChanged);
            // 
            // lb_Vs
            // 
            this.lb_Vs.AutoSize = true;
            this.lb_Vs.Location = new System.Drawing.Point(1267, 776);
            this.lb_Vs.Name = "lb_Vs";
            this.lb_Vs.Size = new System.Drawing.Size(34, 25);
            this.lb_Vs.TabIndex = 5;
            this.lb_Vs.Text = "vs";
            // 
            // tb_ScoreKiri
            // 
            this.tb_ScoreKiri.Location = new System.Drawing.Point(990, 842);
            this.tb_ScoreKiri.Name = "tb_ScoreKiri";
            this.tb_ScoreKiri.Size = new System.Drawing.Size(212, 31);
            this.tb_ScoreKiri.TabIndex = 6;
            this.tb_ScoreKiri.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_ScoreKiri_KeyPress);
            // 
            // tb_ScoreKanan
            // 
            this.tb_ScoreKanan.Location = new System.Drawing.Point(1353, 842);
            this.tb_ScoreKanan.Name = "tb_ScoreKanan";
            this.tb_ScoreKanan.Size = new System.Drawing.Size(212, 31);
            this.tb_ScoreKanan.TabIndex = 7;
            this.tb_ScoreKanan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_ScoreKanan_KeyPress);
            // 
            // bt_AddMatch
            // 
            this.bt_AddMatch.Location = new System.Drawing.Point(1124, 949);
            this.bt_AddMatch.Name = "bt_AddMatch";
            this.bt_AddMatch.Size = new System.Drawing.Size(139, 55);
            this.bt_AddMatch.TabIndex = 8;
            this.bt_AddMatch.Text = "Add Match";
            this.bt_AddMatch.UseVisualStyleBackColor = true;
            this.bt_AddMatch.Click += new System.EventHandler(this.bt_AddMatch_Click);
            // 
            // bt_AddTeam
            // 
            this.bt_AddTeam.Location = new System.Drawing.Point(1299, 949);
            this.bt_AddTeam.Name = "bt_AddTeam";
            this.bt_AddTeam.Size = new System.Drawing.Size(139, 55);
            this.bt_AddTeam.TabIndex = 9;
            this.bt_AddTeam.Text = "Add Team";
            this.bt_AddTeam.UseVisualStyleBackColor = true;
            this.bt_AddTeam.Click += new System.EventHandler(this.bt_AddTeam_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2521, 1244);
            this.Controls.Add(this.bt_AddTeam);
            this.Controls.Add(this.bt_AddMatch);
            this.Controls.Add(this.tb_ScoreKanan);
            this.Controls.Add(this.tb_ScoreKiri);
            this.Controls.Add(this.lb_Vs);
            this.Controls.Add(this.comboBox_Kanan);
            this.Controls.Add(this.comboBox_Kiri);
            this.Controls.Add(this.bt_Delete);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.dateTimePicker1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button bt_Delete;
        private System.Windows.Forms.ComboBox comboBox_Kiri;
        private System.Windows.Forms.ComboBox comboBox_Kanan;
        private System.Windows.Forms.Label lb_Vs;
        private System.Windows.Forms.TextBox tb_ScoreKiri;
        private System.Windows.Forms.TextBox tb_ScoreKanan;
        private System.Windows.Forms.Button bt_AddMatch;
        private System.Windows.Forms.Button bt_AddTeam;
    }
}


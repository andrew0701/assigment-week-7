﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        DataTable dt = new DataTable();
         public List<string> dtUtama = new List<string>();
        public List<string> dtKiri = new List<string>();
        public List<string> dtKanan = new List<string>();
        public static Form1 form1;
        string date;
        public Form1()
        {
            InitializeComponent();
            form1 = this;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            date = dateTimePicker1.Value.ToString();
            dt.Columns.Add("Date");
            dt.Columns.Add("Home Team Name");
            dt.Columns.Add("Home Score");
            dt.Columns.Add("Away Score");
            dt.Columns.Add("Away Team Name");
            //comboBox_Kiri.Items.Add()
            dataGridView1.DataSource = dt;
            dtUtama.Add("Boston Celtics");
            dtUtama.Add("Brooklyn Nets");
            dtUtama.Add("New York Knicks");
            dtUtama.Add("Philadelphia 76ers");
            dtUtama.Add("Toronto Raptors");
            dtUtama.Add("Chicago Bulls");
            dtUtama.Add("Cleveland Cavalier");
            dtUtama.Add("Detroit Piston");
            dtUtama.Add("Indiana Pacers");
            dtUtama.Add("Milwauke Bucks");
            dtKiri = dtUtama;
            dtKanan = dtUtama;
            UpdateComboKiri();
            UpdateComboKanan();
            //foreach (string x in dtKiri)
            //{
            //    comboBox_Kiri.Items.Add(x.ToString());
            //}
            //foreach (string x in dtKanan)
            //{
            //    comboBox_Kanan.Items.Add(x.ToString());
            //}
        }

        private void bt_AddTeam_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
            UpdateComboKiri();
            UpdateComboKanan();
        }

        private void comboBox_Kiri_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtKanan.Remove(comboBox_Kiri.SelectedItem.ToString());
            comboBox_Kanan.Items.Clear();
            UpdateComboKanan();
        }

        public void UpdateComboKiri()
        {     
            foreach (string x in dtKiri)
            {
                comboBox_Kiri.Items.Add(x.ToString());
            }
        }
        public void UpdateComboKanan()
        {
            foreach (string y in dtKanan)
            {
                comboBox_Kanan.Items.Add(y.ToString());
            }
        }

        private void comboBox_Kanan_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtKiri.Remove(comboBox_Kanan.SelectedItem.ToString());
            comboBox_Kiri.Items.Clear();
            UpdateComboKiri();
        }

        private void tb_ScoreKiri_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void bt_AddMatch_Click(object sender, EventArgs e)
        {
            dt.Rows.Add(date, comboBox_Kiri.Text, tb_ScoreKiri.Text, tb_ScoreKanan.Text, comboBox_Kanan.Text);
        }

        private void tb_ScoreKanan_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void bt_Delete_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow row in dataGridView1.SelectedRows)
            {
                dt.Rows.RemoveAt(row.Index);
            }
            dataGridView1.DataSource = dt;
        }
    }
}

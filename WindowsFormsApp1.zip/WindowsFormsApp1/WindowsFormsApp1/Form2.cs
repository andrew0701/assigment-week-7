﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void bt_AddForm2_Click(object sender, EventArgs e)
        {
            Form1.form1.dtUtama.Add(tb_TeamAdd.Text);
            //Form1.form1 = new Form1();
            Form1.form1.dtKiri = Form1.form1.dtUtama;
            Form1.form1.dtKanan = Form1.form1.dtUtama;
            //foreach (DataRow x in Form1.form1.dtKiri.Rows)
            //{
            //    Form1.form1.comboBox_Kiri.Items.Add(x.ToString());
            //}
            //foreach (DataRow x in Form1.form1..Rows)
            //{
            //    comboBox_Kanan.Items.Add(x.ToString());
            //}
            string kata = tb_TeamAdd.Text;
            //if (kata ==  )
        }
    }
}
